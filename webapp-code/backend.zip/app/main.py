from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx
import os
import time
import logging
from typing import List, Dict, Any, Optional

app = FastAPI(title="Azure Model Router Web App", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

AZURE_ENDPOINT = os.getenv("AZURE_ENDPOINT", "")
AZURE_API_KEY = os.getenv("AZURE_API_KEY", "")

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 1000
    azure_endpoint: str
    azure_api_key: str
    auth_mode: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    model_used: Optional[str] = None
    response_time: float
    estimated_cost: Optional[float] = None
    complexity_score: Optional[float] = None
    routing_reason: Optional[str] = None

@app.get("/")
async def root():
    return {"message": "Azure Model Router Web App API"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": time.time()}

@app.post("/chat", response_model=ChatResponse)
async def chat_with_model_router(request: ChatRequest):
    """Send chat request to Azure Model Router and return response with routing info"""
    
    if not request.azure_endpoint or not request.azure_api_key:
        raise HTTPException(
            status_code=400, 
            detail="Azure endpoint and API key are required in the request."
        )
    
    azure_payload = {
        "messages": [{"role": msg.role, "content": msg.content} for msg in request.messages],
        "temperature": request.temperature,
        "max_tokens": request.max_tokens
    }
    
    auth_methods = determine_auth_methods(request.azure_api_key, request.auth_mode)
    
    logger.info(f"Sending request to Azure endpoint: {request.azure_endpoint}")
    logger.info(f"Request payload: {azure_payload}")
    
    start_time = time.time()
    
    for i, (auth_description, headers) in enumerate(auth_methods):
        try:
            logger.info(f"Attempting authentication method {i+1}/{len(auth_methods)}: {auth_description}")
            logger.info(f"Request headers: {headers}")
            
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(request.azure_endpoint, json=azure_payload, headers=headers)
                
            end_time = time.time()
            response_time = end_time - start_time
            
            if response.status_code == 200:
                logger.info(f"Authentication successful with method: {auth_description}")
                result = response.json()
                
                response_content = ""
                if "choices" in result and len(result["choices"]) > 0:
                    response_content = result["choices"][0]["message"]["content"]
                
                model_used = result.get("model", "Unknown")
                
                complexity_score = calculate_complexity_score(request.messages)
                
                estimated_cost = estimate_cost(model_used, response_content, request.messages)
                
                routing_reason = get_routing_reason(complexity_score, model_used)
                
                return ChatResponse(
                    response=response_content,
                    model_used=model_used,
                    response_time=response_time,
                    estimated_cost=estimated_cost,
                    complexity_score=complexity_score,
                    routing_reason=routing_reason
                )
            else:
                logger.warning(f"Authentication method {auth_description} failed with status {response.status_code}: {response.text}")
                if i == len(auth_methods) - 1:
                    logger.error(f"All authentication methods failed. Final error - Status: {response.status_code}, Response: {response.text}")
                    raise HTTPException(
                        status_code=response.status_code,
                        detail=f"Azure API authentication failed (Status {response.status_code}): {response.text}. Tried {len(auth_methods)} authentication methods."
                    )
                    
        except httpx.TimeoutException:
            if i == len(auth_methods) - 1:
                raise HTTPException(status_code=504, detail="Request to Azure API timed out")
        except Exception as e:
            if i == len(auth_methods) - 1:
                logger.error(f"Error calling Azure API: {str(e)}")
                raise HTTPException(status_code=500, detail=f"Error calling Azure API: {str(e)}")
    
    raise HTTPException(status_code=500, detail="Unexpected error: no authentication methods were attempted")

def determine_auth_methods(api_key: str, auth_mode: Optional[str] = None) -> List[tuple]:
    """Determine authentication methods to try based on credential format and auth_mode"""
    
    auth_methods = []
    
    if auth_mode:
        if auth_mode.lower() == "key":
            auth_methods.append(("Direct API Key", {
                "Content-Type": "application/json",
                "Authorization": api_key
            }))
        elif auth_mode.lower() in ["aad_token", "aml_token"]:
            auth_methods.append((f"Bearer Token ({auth_mode})", {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}"
            }))
    else:
        if api_key.startswith("Bearer "):
            auth_methods.append(("Bearer Token (from credential)", {
                "Content-Type": "application/json",
                "Authorization": api_key
            }))
        elif len(api_key) > 100 and ("." in api_key or api_key.startswith("ey")):
            auth_methods.append(("Bearer Token (JWT-like)", {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}"
            }))
            auth_methods.append(("Direct API Key", {
                "Content-Type": "application/json",
                "Authorization": api_key
            }))
        else:
            auth_methods.append(("Direct API Key", {
                "Content-Type": "application/json",
                "Authorization": api_key
            }))
            auth_methods.append(("Bearer Token", {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}"
            }))
    
    return auth_methods

def calculate_complexity_score(messages: List[ChatMessage]) -> float:
    """Calculate complexity score for routing analysis"""
    total_length = sum(len(msg.content) for msg in messages)
    
    technical_keywords = [
        'algorithm', 'architecture', 'microservices', 'kubernetes', 'distributed',
        'quantum', 'machine learning', 'neural network', 'blockchain', 'cryptography',
        'optimization', 'scalability', 'performance', 'security', 'database',
        'api', 'framework', 'design pattern', 'data structure', 'complexity analysis'
    ]
    
    keyword_count = 0
    for msg in messages:
        content_lower = msg.content.lower()
        keyword_count += sum(1 for keyword in technical_keywords if keyword in content_lower)
    
    length_score = min(total_length / 1000, 1.0)  # Cap at 1.0
    keyword_score = min(keyword_count / 10, 1.0)  # Cap at 1.0
    
    return (length_score * 0.6 + keyword_score * 0.4)

def estimate_cost(model_used: str, response: str, messages: List[ChatMessage]) -> float:
    """Estimate cost based on model and token usage (rough estimates)"""
    
    input_tokens = sum(len(msg.content) for msg in messages) // 4
    output_tokens = len(response) // 4
    
    cost_per_1k_tokens = {
        "gpt-4": {"input": 0.03, "output": 0.06},
        "gpt-4-turbo": {"input": 0.01, "output": 0.03},
        "gpt-3.5-turbo": {"input": 0.0015, "output": 0.002},
        "gpt-4o": {"input": 0.005, "output": 0.015},
        "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
    }
    
    model_costs = cost_per_1k_tokens.get(model_used.lower(), cost_per_1k_tokens["gpt-3.5-turbo"])
    
    input_cost = (input_tokens / 1000) * model_costs["input"]
    output_cost = (output_tokens / 1000) * model_costs["output"]
    
    return round(input_cost + output_cost, 6)

def get_routing_reason(complexity_score: float, model_used: str) -> str:
    """Determine routing reason based on complexity and model"""
    
    if complexity_score < 0.3:
        return f"Low complexity ({complexity_score:.2f}) → Routed to efficient model for cost optimization"
    elif complexity_score < 0.7:
        return f"Medium complexity ({complexity_score:.2f}) → Routed to balanced model"
    else:
        return f"High complexity ({complexity_score:.2f}) → Routed to advanced model for best quality"

@app.get("/test-prompts")
async def get_test_prompts():
    """Get predefined test prompts of varying complexity"""
    return {
        "simple": [
            "Hello, how are you?",
            "What's the weather like?",
            "Thanks for your help!",
            "Can you help me?",
            "Good morning!"
        ],
        "medium": [
            "Explain the difference between REST and GraphQL APIs",
            "How do I optimize database queries?",
            "What are the benefits of microservices architecture?",
            "Write a Python function to calculate fibonacci numbers",
            "Explain object-oriented programming concepts"
        ],
        "complex": [
            "Design a comprehensive microservices architecture for an e-commerce platform, including service discovery, load balancing, circuit breakers, distributed tracing, event sourcing, CQRS patterns, and deployment strategies using Kubernetes with detailed implementation examples.",
            "Provide a detailed analysis of quantum computing algorithms, including Shor's algorithm, Grover's algorithm, and their implications for cryptography, with mathematical proofs and implementation considerations for NISQ devices.",
            "Explain how to implement a high-performance blockchain consensus algorithm with Byzantine fault tolerance, including detailed code examples and performance optimization strategies.",
            "Design a scalable machine learning pipeline for real-time fraud detection with feature engineering, model training, deployment strategies, and monitoring systems.",
            "Create a comprehensive security architecture for a distributed system including authentication, authorization, encryption, network security, and compliance considerations."
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
